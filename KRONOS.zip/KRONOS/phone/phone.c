#include <stdio.h>

/* Constants */

#define STRLEN 64
#define PHONE "phone"

/* Defaults */

int TM=180;
int TC=40;
int TP=20;
int TS=10;
int TR=60;
int TN=3;
int NDIG=2;

/* Global variables */

char myself[STRLEN];

/* Functions */

void setparam(cp,ac)
char *cp; 
int ac;
{
  if(!strcmp(cp,"TM")) TM=ac;
  else if(!strcmp(cp,"TC")) TC=ac;
  else if(!strcmp(cp,"TP")) TP=ac;
  else if(!strcmp(cp,"TS")) TS=ac;
  else if(!strcmp(cp,"TR")) TR=ac;
  else if(!strcmp(cp,"TN")) TN=ac;
  else if(!strcmp(cp,"NDIG")) NDIG=ac;
  else {
    fprintf(stdout,"%s: unknown parameter %s\n",myself,cp);
    exit(1);
  }
}

void uc() 
{
  FILE *fpt;
  char file[STRLEN];

  fprintf(stdout,"%s: + %s.tg ...\n",myself,"uc");
  strcpy(file,"uc.tg");
  if((fpt=fopen(file,"w"))==NULL) {
    fprintf(stdout,"%s: cannot open file %s\n",myself,file);
    exit(1);
  }
  fprintf(fpt,"#states 6\n");
  fprintf(fpt,"#trans 9\n"); 
  fprintf(fpt,"#clocks 1 X0\n");
  fprintf(fpt,"\nstate: 0\n");
  fprintf(fpt,"prop: LIBRE\n");
  fprintf(fpt,"invar: TRUE\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"TRUE => DECROCHER; reset{X0}; goto 1\n"); 
  fprintf(fpt,"\nstate: 1\n");
  fprintf(fpt,"prop: DECR\n");
  fprintf(fpt,"invar: X0=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X0=0 => DEBUT_COMP; reset{X0}; goto 2\n"); 
  fprintf(fpt,"\nstate: 2\n");
  fprintf(fpt,"invar: TRUE\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"TRUE => INT_COMP; reset{X0}; goto 0\n"); 
  fprintf(fpt,"TRUE => PRET_A_SONNER; reset{X0}; goto 3\n"); 
  fprintf(fpt,"\nstate: 3\n");
  fprintf(fpt,"invar: X0=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X0=0 => DEBUT_SONNERIE; reset{X0}; goto 4\n"); 
  fprintf(fpt,"\nstate: 4\n");
  fprintf(fpt,"invar: TRUE\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"TRUE => INT_SONNERIE; reset{X0}; goto 0\n"); 
  fprintf(fpt,"TRUE => CONNECTION; reset{X0}; goto 5\n"); 
  fprintf(fpt,"\nstate: 5\n");
  fprintf(fpt,"prop: CONNECT\n");
  fprintf(fpt,"invar: X0<=%d\n",TM);
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X0=%d => INT_COMM; reset{X0}; goto 0\n",TM); 
  fprintf(fpt,"X0<%d => RACROCHER; reset{X0}; goto 0\n",TM); 
  fclose(fpt);
}

void ugs() 
{
  FILE *fpt;
  char file[STRLEN];

  fprintf(stdout,"%s: + %s.tg ...\n",myself,"ugs");
  strcpy(file,"ugs.tg");
  if((fpt=fopen(file,"w"))==NULL) {
    fprintf(stdout,"%s: cannot open file %s\n",myself,file);
    exit(1);
  }
  fprintf(fpt,"#states 5\n");
  fprintf(fpt,"#trans 8\n"); 
  fprintf(fpt,"#clocks 2 X1 X2\n");
  fprintf(fpt,"\nstate: 0\n");
  fprintf(fpt,"invar: TRUE\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"TRUE => DEBUT_SONNERIE; reset{X2}; goto 1\n"); 
  fprintf(fpt,"\nstate: 1\n");
  fprintf(fpt,"prop: DSON\n");
  fprintf(fpt,"invar: X2=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X2=0 => SONNER; reset{X1,X2}; goto 2\n"); 
  fprintf(fpt,"\nstate: 2\n");
  fprintf(fpt,"invar: X1<=%d and X2<=%d\n",TR,TN);
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X2=%d => SONNER; reset{X2}; goto 2\n",TN); 
  fprintf(fpt,"X1=%d => TIMEOUT1; reset{X1,X2}; goto 4\n",TR); 
  fprintf(fpt,"X1<%d and X2<%d => RACROCHER; reset{X1,X2}; goto 4\n",TR,TN); 
  fprintf(fpt,"X1<%d and X2<%d => CONNECTER; reset{X1,X2}; goto 3\n",TR,TN); 
  fprintf(fpt,"\nstate: 3\n");
  fprintf(fpt,"invar: X1=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X1=0 => CONNECTION; reset{X1,X2}; goto 0\n"); 
  fprintf(fpt,"\nstate: 4\n");
  fprintf(fpt,"invar: X1=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X1=0 => INT_SONNERIE; reset{X0}; goto 0\n"); 
  fclose(fpt);
}

void ugn()
{
  int i;
  FILE *fpt;
  char file[STRLEN];

  fprintf(stdout,"%s: + %s.tg ...\n",myself,"ugn");
  strcpy(file,"ugn.tg");
  if((fpt=fopen(file,"w"))==NULL) {
    fprintf(stdout,"%s: cannot open file %s\n",myself,file);
    exit(1);
  } 
  if(NDIG<1) {
    fprintf(stdout,"%s: NDIG must be greater than 0\n",myself);
    exit(1);
  } 
  fprintf(fpt,"#states %d\n",NDIG+3);
  fprintf(fpt,"#trans %d\n",6+(NDIG-1)*3); 
  fprintf(fpt,"#clocks 2 X3 X4\n");
  fprintf(fpt,"\nstate: 0\n");
  fprintf(fpt,"invar: TRUE\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"TRUE => DEBUT_COMP; reset{X3,X4}; goto 1\n"); 
  fprintf(fpt,"\nstate: 1\n");
  fprintf(fpt,"invar: X3<=%d and X4<=%d\n",TC,TP);
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X3=%d or X4=%d",TC,TP);
  fprintf(fpt," => TIMEOUT2; reset{X3,X4}; goto %d\n",NDIG+2); 
  fprintf(fpt,"X3<%d and X4<%d",TC,TP);
  fprintf(fpt," => RACROCHER; reset{X3,X4}; goto %d\n",NDIG+2); 
  fprintf(fpt,"X3<%d and X4<%d",TC,TP);
  fprintf(fpt," => CHIFFRE1; reset{X4}; goto 2\n"); 
  for(i=1;i<NDIG;i++) {
    fprintf(fpt,"\nstate: %d\n",i+1);
    fprintf(fpt,"prop: CHIFF%d\n",i);
    fprintf(fpt,"invar: X3<=%d and X4<=%d\n",TC,TS);
    fprintf(fpt,"trans:\n");
    fprintf(fpt,"X3=%d or X4=%d",TC,TS);
    fprintf(fpt," => TIMEOUT2; reset{X3,X4}; goto %d\n",NDIG+2); 
    fprintf(fpt,"X3<%d and X4<%d",TC,TS);
    fprintf(fpt," => RACROCHER; reset{X3,X4}; goto %d\n",NDIG+2); 
    fprintf(fpt,"X3<%d and X4<%d",TC,TS);
    fprintf(fpt," => CHIFFRE%d; reset{X4}; goto %d\n",i+1,i+2); 
  }
  fprintf(fpt,"\nstate: %d\n",NDIG+1);
  fprintf(fpt,"prop: CHIFF%d END_DIAL\n",NDIG);
  fprintf(fpt,"invar: X4=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X4=0 => PRET_A_SONNER; reset{X3,X4}; goto 0\n");
  fprintf(fpt,"\nstate: %d\n",NDIG+2);
  fprintf(fpt,"invar: X4=0\n");
  fprintf(fpt,"trans:\n");
  fprintf(fpt,"X4=0 => INT_COMP; reset{X3,X4}; goto 0\n");
  fclose(fpt);
}

void phone()
{
  uc();
  ugs();
  ugn();
}

main(argc,argv)
int argc;
char *argv[];
{
  int i, j;
  char cp[STRLEN], line[STRLEN], file[STRLEN];

  strcpy(myself,argv[0]);
  fprintf(stdout,"%s: replacing parameters ...\n",myself);
  for(i=1;i<argc;i++) {
    j=0;
    while(argv[i][j]!='=') {
      cp[j]=argv[i][j];
      j++;
    }
    cp[j]='\0';
    setparam(cp,atoi(argv[i]+(j+1)));
  }
  phone();
  sprintf(line,"ptg uc.tg ugs.tg ugn.tg\n");
  system(line);
  sprintf(line,"/bin/rm -f uc.tg ugs.tg ugn.tg\n");
  system(line);
  sprintf(file,"%s.tg",PHONE);
  sprintf(line,"mv _out.tg %s\n",file);
  system(line);
  fprintf(stdout,"%s: file %s dumped\n",myself,file);
  fprintf(stdout,"%s: done\n",myself);
}
